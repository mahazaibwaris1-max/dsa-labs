#include <iostream>
using namespace std;

class Course
{
public:
    virtual void duration() = 0;
    virtual ~Course() {}
};

class OnlineCourse : public Course
{
private:
    int weeks;
    int hoursPerWeek;

public:
    OnlineCourse(int w, int h)
    {
        weeks = w;
        hoursPerWeek = h;
    }

    void duration()
    {
        cout << "Online Course Duration: " << weeks << " weeks, "
             << weeks * hoursPerWeek << " total hours" << endl;
    }
};

class OfflineCourse : public Course
{
private:
    int months;
    int hoursPerDay;

public:
    OfflineCourse(int m, int h)
    {
        months = m;
        hoursPerDay = h;
    }

    void duration()
    {
        cout << "Offline Course Duration: " << months << " months, "
             << months * 30 * hoursPerDay << " approximate total hours" << endl;
    }
};

int main()
{
    OnlineCourse online(8, 5);
    OfflineCourse offline(3, 4);

    online.duration();
    offline.duration();

    return 0;
}
